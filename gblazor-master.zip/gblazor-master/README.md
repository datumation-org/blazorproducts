# GBlazor
Unity-GB Emulator (C# Gameboy emulator) running in the browser using Blazor (mono-wasm) 
